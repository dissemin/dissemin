# Parameters
deposit_url = ''

packaging = 'http://purl.org/net/sword/package/METSMODS'

auth = ('user', 'password')
