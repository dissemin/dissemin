
=head1 NAME

EPrints::Plugin::Import::METSMODS_Broker

=head1 DESCRIPTION

A SWORD 2 Importer for METS/MODS Data.

The METSMODS_package is a zip file, with 0+ files in 0+ directories, and a mets.xml file in the root directory.
The metadata in the XML file is described at L<http://www.loc.gov/standards/mods/mods-outline-3-7.html>

This package unpacks the .zip file and creates a complete eprint (metadata and 0+ files) from the single I<create> function.

=cut

package EPrints::Plugin::Import::METSMODS_Broker;

use strict;

use EPrints::Plugin::Import::Binary;
use EPrints::Plugin::Import::Archive;
use EPrints::Plugin::Import::METSMODS_Broker_mods_parser;
use Data::Dumper;

use XML::LibXML 1.63;
use Archive::Extract;

our @ISA = qw/ EPrints::Plugin::Import::Archive
    EPrints::Plugin::Import::METSMODS_Broker_mods_parser  /;

#===  CLASS METHOD  ===========================================================
#        CLASS:  METSMODS_Broker
#       METHOD:  new
#   PARAMETERS:  %params
#      RETURNS:  $plugin object
#  DESCRIPTION:  Creates a new importer plugin object and registers it with
#                EPrints
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  n/a
#==============================================================================
sub new {
    my ( $class, %params ) = @_;

    my $self = $class->SUPER::new(%params);

    # The name to display
    $self->{name} = "METSMODS Importer";

    # Who can see it, and whether we show it
    $self->{visible}   = "all";
    $self->{advertise} = 1;

    # What the importer produces
    $self->{produce} = [qw( list/eprint dataobj/eprint )];

    # What mime-types can trigger this importer
    $self->{accept} = [
        "application/mets+xml; charset=utf-8", "sword:http://purl.org/net/sword/package/METSMODS"
    ];

    return $self;
} ## end sub new

#===  CLASS METHOD  ============================================================
#        CLASS:  METSMODS_Broker
#       METHOD:  input_fh
#   PARAMETERS:  %opts - options
#      RETURNS:  an EPrint::List of imported records
#  DESCRIPTION:  This is main import routine: it unpacks the file at the end
#                of the filehandle; reads in the mets.xml file & creates the
#                metadata; attaches each file in each directory; and then creates
#                an eprint-object from that record.
#       THROWS:  no exceptions
#     COMMENTS:  none
#     SEE ALSO:  METSMODS_Broker_mods_parser
#===============================================================================
sub input_fh {
    my ( $plugin, %opts ) = @_;

    my $fh      = $opts{fh};
    my $dataset = $opts{dataset};
    my $repo    = $plugin->{session};

    my @ids;

    # get the type of file (should be zip) and the filename ($zipfile) for
    # the file just deposited.
    # (local method)
    my ( $type, $zipfile ) = $plugin->upload_archive($fh);

    # This is localised simply so we can have a bunch of variables to deduce
    # the METS file I want (I know the file will be called mets.xml, and I
    # know it will be at the top of the tree.
    # It also barfs if we can't unzip the file given.
    {
        my $ae = Archive::Extract->new( archive => $zipfile, type => 'zip' );

        my $tmp_dir = File::Temp->newdir();

        if ( !defined $tmp_dir ) {
            my $message
                = "\n[SWORD-DEPOSIT] [INTERNAL-ERROR] Failed to create the temp directory!";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                500, $message );
            return;
        } ## end if ( !defined $tmp_dir)

        ## extract files into $tmp_dir
        my $ok = $ae->extract( to => $tmp_dir );

        unless ($ok) {
            my $message
                = "\n[SWORD-DEPOSIT] [INTERNAL-ERROR] Failed to unpack zip-file!";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                500, $message );
            return;
        } ## end unless ($ok)
        my $files = $ae->files;

        unless ( defined $files ) {
            my $message = "\n[ERROR] failed to unpack the files";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                500, $message );
            return;
        } ## end unless ( defined $files )

        # get the directory with the unpacked files in it.
        my $dir = $ae->extract_path;
        my @candidates = grep ( /^mets.xml$/, @{$files} );

        if ( scalar(@candidates) == 0 ) {
            my $message = "\n[ERROR] could not find the XML file!";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end if ( scalar(@candidates...))

        my $file = $candidates[0];

        # $dir is the temporary directory
        # $file is the name of the mets.xml file in that directory

        my $dataset_id   = $opts{dataset_id};
        my $owner_id     = $opts{owner_id};
        my $depositor_id = $opts{depositor_id};

        my $fh;
        if ( !open( $fh, "$dir/$file" ) ) {
            my $message
                = "\n[ERROR] couldnt open the file: '$file' because '$!'";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                500, $message );
            return;
        } ## end if ( !open( $fh, "$dir/$file"...))

        # Finally, we can read the xml from the file:
        my $xml;
        while ( my $d = <$fh> ) {
            $xml .= $d;
        }
        close $fh;

        # again, barf if the dataset is not provided (though as this is
        # through SWORD, this shouldn't happen
        if ( !defined $dataset ) {
            my $message
                = "\n[INTERNAL ERROR] dataset (object type) not given!";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                500, $message );
            return;
        } ## end if ( !defined $dataset)

        # convert the xml text to a LibXML dom-object
        # What EPrints doesn't do is validate, it just checks for
        # well-formed-ness
        # We have it in an eval block in case the xml is not well-formed,
        # as the parser throws an exception if the document is invalid
        my $dom_doc;
        eval { $dom_doc = EPrints::XML::parse_xml_string( $xml ); };

        # No dom? barf
        if ( $@ || !defined $dom_doc ) {
            my $message = "\n[ERROR] failed to parse the xml: '$@'";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end if ( $@ || !defined $dom_doc)

        if ( !defined $dom_doc ) {
            my $message = "\n[ERROR] failed to parse the xml.";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end if ( !defined $dom_doc)

        # If we have got here, we can delete the original mets.xml file
        my $files2 = [];
        @{$files2} = grep ( !/^mets.xml$/, @{$files} );

        # If the top element is not mets, barf
        # This is just in case someone sends us a non METS xml file
        my $dom_top = $dom_doc->getDocumentElement;

        if ( lc $dom_top->tagName ne 'mets:mets' ) {
            my $message
                = "\n[ERROR] failed to parse the xml: no <mets> tag found.";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end if ( lc $dom_top->tagName...)

        # Now we dig down to get the xmldata from metsHdr and the internal dmdSec MODS section
        my $METS_namespace = "http://www.loc.gov/METS/";
        my $MODS_namespace = "http://www.loc.gov/mods/v3";        

        # METS Headers 
        my $mets_hdr = ( $dom_top->getElementsByTagNameNS( $METS_namespace, "metsHdr" ) )[0];
        if( !defined $mets_hdr )
        {
            my $message
                = "\n[ERROR] failed to parse the xml: could not find METS Header /metsHdr";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } 
        
        my $agent = ( $mets_hdr->getChildrenByTagNameNS( $METS_namespace, "agent" ) )[0];        
        if( !defined $agent )
        {
        	my $message
                = "\n[ERROR] failed to parse the xml: could not find project name /metsHdr/agent";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } 
        
        my $agent_name = ( $agent->getChildrenByTagNameNS( $METS_namespace, "name" ) )[0];
        if( !defined $agent_name )
        {
            my $message
                = "\n[ERROR] failed to parse the xml: could not find project name /metsHdr/agent/name";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        }
        
		# parse project name
        my $project = EPrints::Utils::tree_to_utf8( $agent_name );              

        # METS Descriptive Metadata (main section for us)
        # need to loop on dmdSec:
        my @dmd_sections = $dom_top->getElementsByTagNameNS( $METS_namespace, "dmdSec" );
        my $dmd_id;
        my $md_wrap;
        my $xml_type;
        my $found_mods_wrapper = 0;

        # METS can have more than one dmdSec, and we can't assume that what's
        # pushed in conforms to what we want, so we want to find the dmdSec 
        # which contains the MODS Metadata
        foreach my $dmd_sec (@dmd_sections) {
            # need to extract xmlData from here
            $md_wrap = ( $dmd_sec->getElementsByTagNameNS( $METS_namespace, "mdWrap" ) )[0];

            next if ( !defined $md_wrap );

			# Unterscheidung der XML Typen
            if ( defined ( ( $md_wrap->getElementsByTagNameNS( $MODS_namespace, "mods" ) )[0] ) ){
            	$xml_type      = "mods";
            	$found_mods_wrapper = 1;            	
            }
            
            $dmd_id = $dmd_sec->getAttribute("ID");
            last;
        } ## end foreach my $dmd_sec (@dmd_sections)

        unless ($found_mods_wrapper) {
            my $message
                = "\n[ERROR] failed to parse the xml: could not find MODS <mdWrap> section.";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end unless ($found_mods_wrapper)

        # Now we get the  xml from the xmlData section
        # and parse it into a hash
        my $xml_data = ( $md_wrap->getElementsByTagNameNS( $METS_namespace, "xmlData" ) )[0];

        if ( !defined $xml_data ) {
            my $message
                = "\n[ERROR] failed to parse the xml: no <xmlData> tag found.";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end if ( !defined $xml_data)		
                
        # parse XML type
        my $epdata;
        if ( $xml_type eq "mods" ) {
        	$epdata = $plugin->parse_mods_xml_data( $xml_data, $project );
        } ## end if ($xml_type eq "mods")
        
        if ( !defined $epdata ) {
            my $message
                = "\n[ERROR] failed to parse the xml: <mods> content.";
            $repo->log($message);
            EPrints::Apache::AnApache::send_status_line( $repo->{"request"},
                400, $message );
            return;
        } ## end if ( !defined $xml_data)   
        
        # We now want to deal with the associated files (if any).
        # This is not a straight "every file is a document" import: EPrints
        # has this weird thing where a "document" can have multiple files. The
        # Broker deals with this by having defining the structure in
        # <structMap>, and putting each document into a <div>. If there are
        # multiple files, the main file is the first file in the set

        # The first thing to do is create a list of all the files & their IDs
        # File Section which will contain optional info about files to import:
        my %files;

        # we also need to hang onto details about where the importer unpacked
        # stuff. I know it's nothing to do with files in the METS manifest, however
        # this is probably the best place to keep them :)
        $files{unpack_dir} = $dir;

        my $file_counter = 0;
        foreach my $file_sec ( $dom_top->getElementsByTagNameNS( $METS_namespace, "fileSec" ) ) {
            my $file_grp = ( $file_sec->getChildrenByTagNameNS( $METS_namespace, "fileGrp" ) )[0];
            if ( defined $file_grp ){
          		$file_sec = $file_grp;                	
            }

            foreach my $file_div ( $file_sec->getChildrenByTagNameNS( $METS_namespace, "file" ) ) {
                my $file_id = $file_div->getAttribute("ID");
                my $file_loc = ( $file_div->getChildrenByTagNameNS( $METS_namespace, "FLocat" ) )[0];
                if ( defined $file_loc ) {    # yeepee we have a file (maybe)

                    my $fn = $file_loc->getAttribute("href");
                    unless ( defined $fn ) {
                        # to accommodate the gdome XML library:
                        $fn = $file_loc->getAttribute("xlink:href");
                    }

                    next unless ( defined $fn );

                    $files{$file_id} = $fn;    # list files to get locally
                } ## end if ( defined $file_loc)
            } ## end foreach my $file_div ( $file_sec...)
        } ## end foreach my $file_sec ( $dom_top...)

        unless ( scalar keys %files ) {
            $plugin->add_verbose(
                "[WARNING] no <fileSec> tag found: no files will be imported."
            );
        }
		
        # Having determined what files we have to add to the deposit, we need
        # to create a "map" of what files go where from the <structMap> element.
        $xml_data = "";
        my $amdSec = ( $dom_top->getElementsByTagNameNS( $METS_namespace, "amdSec" ) )[0];
        if ( defined $amdSec ){
        	$xml_data = ( $amdSec->getElementsByTagNameNS( $METS_namespace, "xmlData") )[0];
        }        
        
        # Rights Data Hashmap which will contain optional info about rights data:
        my %rights_data = $plugin->parse_rights_data( $xml_data, $project );
        my $struct_map = ( $dom_top->getElementsByTagNameNS( $METS_namespace, "structMap") )[0];
        my $struct_div = ( $struct_map->getChildrenByTagNameNS( $METS_namespace, "div") )[0];
        
        my $doc = $plugin->process_struct_elements( $struct_div, \%files, \%rights_data );
        if (defined $doc){
            $epdata->{documents} = $doc;
        }
        
        $plugin->write_rightsMD_info_to_metadata( \%rights_data, $epdata );
	        

	    # and finally create the eprint object from the dataset
	    my $dataobj = $plugin->epdata_to_dataobj( $dataset, $epdata );
	      
	    if ( defined $dataobj ) {
	       push @ids, $dataobj->get_id;
	    } 	    
	        
	    return EPrints::List->new(
            dataset => $dataset,
            session => $repo,
            ids     => \@ids
        ); 
        
    }
} ## end sub input_fh

####################################################################

=pod

=item $success = $doc->upload_archive( $filehandle, $filename, $archive_format )

Upload the contents of the given archive file. 

(In case the over-loading of the word "archive" is getting confusing,
in this context we mean ".zip" or ".tar.gz" archive.)

=cut

#####################################################################

sub upload_archive {
    my ( $self, $fh ) = @_;

    use bytes;

    binmode($fh);

    my $zipfile = File::Temp->new();
    binmode($zipfile);

    my $rc;
    my $lead;
    while ( $rc = sysread( $fh, my $buffer, 4096 ) ) {
        $lead = $buffer if !defined $lead;
        syswrite( $zipfile, $buffer );
    }
    EPrints->abort("Error reading from file handle: $!") if !defined $rc;

    my $type = substr( $lead, 0, 2 ) eq "PK" ? "zip" : "targz";

    return ( $type, $zipfile );
} ## end sub upload_archive

sub parse_rights_data {
    my ( $plugin, $xml, $project ) = @_;
    
    my $repo    = $plugin->{session};
    my %data = {};    
    
    if ( defined $project )
    {
    	if ( $project eq 'Dissemin' )
    	{
    	   %data = $plugin->parse_dissemin_rights_data( $xml );   	   
    	} 
    	$data{project} = $project;
    }      
       
    return %data;
}

# parse DISSEMIN related RightsData
sub parse_dissemin_rights_data {
	my ( $plugin, $xml ) = @_;
	
	my $repo    = $plugin->{session};
	my %data = {}; 
	
    my $DS_namespace   = "https://dissem.in/deposit/terms/";
    my $dissemin_data = ( $xml->getChildrenByTagNameNS( $DS_namespace, "dissemin") )[0];
    
    if ( defined $dissemin_data ) {    	
        # <ds:depositor>
        #     <ds:authentication>orcid</ds:authentication>
        #     <ds:firstName>Gottfried</ds:firstName>
        #     <ds:lastName>Leibniz</ds:lastName>
        #     <ds:email>gottfried.leibniz@tib.eu</ds:email>
        #     <ds:orcid>2543-2454-2345-234X</ds:orcid>
        #     <ds:isContributor>false</ds:isContributor>
        # </ds:depositor>
    	my $depositor = ( $dissemin_data->getChildrenByTagNameNS( $DS_namespace, "depositor" ) )[0];
    	if ( defined $depositor ) {           
            # get contact email of depositor
            my $contact_email = ( $depositor->getChildrenByTagNameNS( $DS_namespace, "email" ) )[0]; 
            if( defined $contact_email ) {
            	$data{depositor_contact_email} = EPrints::Utils::tree_to_utf8( $contact_email );
            }
            
            # get first name of depositor
            my $first_name = ( $depositor->getChildrenByTagNameNS( $DS_namespace, "firstName" ) )[0]; 
            if( defined $first_name ) {
                $data{depositor_first_name} = EPrints::Utils::tree_to_utf8( $first_name );
            }
            
            # get last name of depositor
            my $last_name = ( $depositor->getChildrenByTagNameNS( $DS_namespace, "lastName" ) )[0]; 
            if( defined $last_name ) {
                $data{depositor_last_name} = EPrints::Utils::tree_to_utf8( $last_name );
            }
            
            # get orcid of depositor
            my $orcid = ( $depositor->getChildrenByTagNameNS( $DS_namespace, "orcid" ) )[0]; 
            if( defined $orcid ) {
                $data{depositor_orcid} = EPrints::Utils::tree_to_utf8( $orcid );
            }
    	}

        # <ds:publication>
        #   <ds:license>
        #     <ds:licenseName>Creative Commons Attribution 4.0 International (CC BY 4.0)</ds:licenseName>
        #     <ds:licenseURI>https://creativecommons.org/licenses/by/4.0/</ds:licenseURI>
        #     <ds:licenseTransmitId>cc_by-40</ds:licenseTransmitId>
        #   </ds:license>
        #   <ds:disseminId>6</ds:disseminId>
        #   <ds:embargoDate>2020-12-31</ds:embargoDate>
        #   <ds:romeoId>1423</ds:romeoId>
        # </ds:publication>
    	my $publication = ( $dissemin_data->getChildrenByTagNameNS( $DS_namespace, "publication" ) )[0];
    	if ( defined $publication ) {
    		my $license = ( $publication->getChildrenByTagNameNS( $DS_namespace, "license" ) )[0];
    		if ( defined $license ) {
    			my $license_id = ( $license->getChildrenByTagNameNS( $DS_namespace, "licenseTransmitId" ) )[0];
    			if ( defined $license_id ){
                    $data{license} = EPrints::Utils::tree_to_utf8( $license_id );
                }
    		}
    		
    		my $embargo = ( $publication->getChildrenByTagNameNS( $DS_namespace, "embargoDate" ) )[0];
    		if( defined $embargo ) {
    			$data{embargo} = EPrints::Utils::tree_to_utf8( $embargo );
    		}
    	}   
    }
    
    return %data;
}

# This function is used to write the values of the parsed tags 
# from <rightsMD> section in the metadata fields. The interpretation 
# depends on the project.
sub write_rightsMD_info_to_metadata{
	my ( $plugin, $rights_data_hashref, $epdata ) = @_;
	
	if( $rights_data_hashref->{project} eq "Dissemin" )
	{
		$plugin->write_dissemin_rightsMD_info_to_metadata( $rights_data_hashref, $epdata );
	}
}

# This function is used to write the values of the parsed tags 
# from <rightsMD> section in the metadata fields. The interpretation 
# is for DISSEMIN project.
sub write_dissemin_rightsMD_info_to_metadata{
    my ( $plugin, $rights_data_hashref, $epdata ) = @_;
    
    my @contributors_array = ();
    
    my $full_name = {};
    
    if ( exists $rights_data_hashref->{depositor_first_name} )
    {
    	$full_name->{given} = $rights_data_hashref->{depositor_first_name};
    }
    
    if ( exists $rights_data_hashref->{depositor_last_name} )
    {
        $full_name->{family} = $rights_data_hashref->{depositor_last_name};
    }
    
    if ( exists $rights_data_hashref->{depositor_orcid} ){
        push @contributors_array, {type=>"http://www.loc.gov/loc.terms/relators/DPT", name => $full_name, id => $rights_data_hashref->{depositor_orcid}};
    } else {
        push @contributors_array, {type=>"http://www.loc.gov/loc.terms/relators/DPT", name => $full_name, id => ""};
    }
    
    if ( scalar @contributors_array > 0 ){
        $epdata->{contributors} = \@contributors_array;
    }
    
    if ( exists $rights_data_hashref->{depositor_contact_email} ){
    	$epdata->{contact_email} = $rights_data_hashref->{depositor_contact_email};
    }
}

# This is where we actually track & build the stuff that
# adds the files. It also sets any embargo period.
# As we need the embargo details later on, it returns the
# embargo date and the security restriction.
sub process_struct_elements {
    #my ( $plugin, $node_ref, $files_hashref, $project ) = @_;
    my ( $plugin, $node_ref, $files_hashref, $rights_data_hashref ) = @_;
    
    my $documents = [];

    my $unpack_dir   = $files_hashref->{unpack_dir};
    
    my ( $embargo, $security );    
    my $license;
    my $project;    
    
    $security = 'public';
    $project  = $rights_data_hashref->{project};
	
    if ( defined $project && $project eq "Dissemin" ) {        
        $license = $rights_data_hashref->{license};
        
        $embargo = $rights_data_hashref->{embargo};
        if ( defined $embargo ) {
            $security = 'staffonly';
        }        
    }

    # Go through all the children
    foreach my $element ( @{$node_ref->getElementsByTagName("div")} ) {
        my $ID = $element->getAttribute("ID");

        #if ( exists $embargo_hash->{$ID} ) {
        #    $embargo = $embargo_hash->{$ID}->{'date'};
        #}

        my @fptrs = $element->getElementsByTagName("fptr");    #childNodes;

        # check to see what element it is
        if ( scalar @fptrs ) {
            my $doc_data = {};
            $doc_data->{files} = [];
            
            # Dissemin license and embargo
            if( $project eq "Dissemin" ) {
            	if( defined $license ) {
            		$doc_data->{license} = $license;
            	} ## end if( defined $license )
            	
            	if( defined $embargo ) {
                    $doc_data->{date_embargo} = $embargo;
            	} ## end if( defined $embargo )           	               
            } ## if( $project eq "Dissemin" )
            
            my $main_filename = "";
            foreach my $fptr (@fptrs) {
                my $fileid = $fptr->getAttribute("FILEID");
                my $file   = $files_hashref->{$fileid};

                my $filename = $file;

                my $filepath = "$unpack_dir/$file";
                
                $doc_data->{security} = $security;

                # If there's more than one file, RJB sets the "main" file to
                # be the first one in the list.
                if ( scalar @fptrs > 1 ) {
                    $doc_data->{filename} = $filename
                        unless exists $doc_data->{filename};
                }

                open( my $fh, "<", $filepath )
                    or die "Error opening $filename: $!";
                push @{ $doc_data->{files} },
                    {
                    filename => $filename,
                    filesize => -s $filepath,
                    _content => $fh,
                    };
                $plugin->{session}->run_trigger( EPrints::Const::EP_TRIGGER_MEDIA_INFO,
					epdata => $doc_data,
					filename => $filename,
					filepath => $filepath,
					);
            } ## end foreach my $fptr (@fptrs)
            push @{$documents}, $doc_data;
        } ## end if ( scalar @fptrs )

    } ## end foreach my $element ( @{$nodes_ref...})
    return $documents;
} ## end sub process_struct_elements

sub keep_deposited_file {
    return 1;
}

1;

=head1 COPYRIGHT

=for COPYRIGHT BEGIN

Copyright 2013 EDINA.
Copyright 2019 University and State Library Darmstadt

=for COPYRIGHT END

=for LICENSE BEGIN

                   GNU LESSER GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.


  This version of the GNU Lesser General Public License incorporates
the terms and conditions of version 3 of the GNU General Public
License, supplemented by the additional permissions listed below.

  0. Additional Definitions.

  As used herein, "this License" refers to version 3 of the GNU Lesser
General Public License, and the "GNU GPL" refers to version 3 of the GNU
General Public License.

  "The Library" refers to a covered work governed by this License,
other than an Application or a Combined Work as defined below.

  An "Application" is any work that makes use of an interface provided
by the Library, but which is not otherwise based on the Library.
Defining a subclass of a class defined by the Library is deemed a mode
of using an interface provided by the Library.

  A "Combined Work" is a work produced by combining or linking an
Application with the Library.  The particular version of the Library
with which the Combined Work was made is also called the "Linked
Version".

  The "Minimal Corresponding Source" for a Combined Work means the
Corresponding Source for the Combined Work, excluding any source code
for portions of the Combined Work that, considered in isolation, are
based on the Application, and not on the Linked Version.

  The "Corresponding Application Code" for a Combined Work means the
object code and/or source code for the Application, including any data
and utility programs needed for reproducing the Combined Work from the
Application, but excluding the System Libraries of the Combined Work.

  1. Exception to Section 3 of the GNU GPL.

  You may convey a covered work under sections 3 and 4 of this License
without being bound by section 3 of the GNU GPL.

  2. Conveying Modified Versions.

  If you modify a copy of the Library, and, in your modifications, a
facility refers to a function or data to be supplied by an Application
that uses the facility (other than as an argument passed when the
facility is invoked), then you may convey a copy of the modified
version:

   a) under this License, provided that you make a good faith effort to
   ensure that, in the event an Application does not supply the
   function or data, the facility still operates, and performs
   whatever part of its purpose remains meaningful, or

   b) under the GNU GPL, with none of the additional permissions of
   this License applicable to that copy.

  3. Object Code Incorporating Material from Library Header Files.

  The object code form of an Application may incorporate material from
a header file that is part of the Library.  You may convey such object
code under terms of your choice, provided that, if the incorporated
material is not limited to numerical parameters, data structure
layouts and accessors, or small macros, inline functions and templates
(ten or fewer lines in length), you do both of the following:

   a) Give prominent notice with each copy of the object code that the
   Library is used in it and that the Library and its use are
   covered by this License.

   b) Accompany the object code with a copy of the GNU GPL and this license
   document.

  4. Combined Works.

  You may convey a Combined Work under terms of your choice that,
taken together, effectively do not restrict modification of the
portions of the Library contained in the Combined Work and reverse
engineering for debugging such modifications, if you also do each of
the following:

   a) Give prominent notice with each copy of the Combined Work that
   the Library is used in it and that the Library and its use are
   covered by this License.

   b) Accompany the Combined Work with a copy of the GNU GPL and this license
   document.

   c) For a Combined Work that displays copyright notices during
   execution, include the copyright notice for the Library among
   these notices, as well as a reference directing the user to the
   copies of the GNU GPL and this license document.

   d) Do one of the following:

       0) Convey the Minimal Corresponding Source under the terms of this
       License, and the Corresponding Application Code in a form
       suitable for, and under terms that permit, the user to
       recombine or relink the Application with a modified version of
       the Linked Version to produce a modified Combined Work, in the
       manner specified by section 6 of the GNU GPL for conveying
       Corresponding Source.

       1) Use a suitable shared library mechanism for linking with the
       Library.  A suitable mechanism is one that (a) uses at run time
       a copy of the Library already present on the user's computer
       system, and (b) will operate properly with a modified version
       of the Library that is interface-compatible with the Linked
       Version.

   e) Provide Installation Information, but only if you would otherwise
   be required to provide such information under section 6 of the
   GNU GPL, and only to the extent that such information is
   necessary to install and execute a modified version of the
   Combined Work produced by recombining or relinking the
   Application with a modified version of the Linked Version. (If
   you use option 4d0, the Installation Information must accompany
   the Minimal Corresponding Source and Corresponding Application
   Code. If you use option 4d1, you must provide the Installation
   Information in the manner specified by section 6 of the GNU GPL
   for conveying Corresponding Source.)

  5. Combined Libraries.

  You may place library facilities that are a work based on the
Library side by side in a single library together with other library
facilities that are not Applications and are not covered by this
License, and convey such a combined library under terms of your
choice, if you do both of the following:

   a) Accompany the combined library with a copy of the same work based
   on the Library, uncombined with any other library facilities,
   conveyed under the terms of this License.

   b) Give prominent notice with the combined library that part of it
   is a work based on the Library, and explaining where to find the
   accompanying uncombined form of the same work.

  6. Revised Versions of the GNU Lesser General Public License.

  The Free Software Foundation may publish revised and/or new versions
of the GNU Lesser General Public License from time to time. Such new
versions will be similar in spirit to the present version, but may
differ in detail to address new problems or concerns.

  Each version is given a distinguishing version number. If the
Library as you received it specifies that a certain numbered version
of the GNU Lesser General Public License "or any later version"
applies to it, you have the option of following the terms and
conditions either of that published version or of any later version
published by the Free Software Foundation. If the Library as you
received it does not specify a version number of the GNU Lesser
General Public License, you may choose any version of the GNU Lesser
General Public License ever published by the Free Software Foundation.

  If the Library as you received it specifies that a proxy can decide
whether future versions of the GNU Lesser General Public License shall
apply, that proxy's public statement of acceptance of any version is
permanent authorization for you to choose that version for the
Library.

=for LICENSE END

